
//Closures store references to the outer function’s variables / parameters; 

function showName (firstName, lastName) 
{

    var nameIntro = "Your name is ";

    function makeFullName () 
        {        
        return nameIntro + firstName + " " + lastName;    
        }
        return makeFullName ();
    }
    var x=showName ("sam", "paul"); 
    console.log(x);