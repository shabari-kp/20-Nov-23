const student = {
    name: 'John ',
    city: 'Kampala'
   };
   
   console.log("old style")
   let message = 'Hello ' + student.name + ' from ' + student.city;
   console.log(message);

   console.log("=====================")
   //using template literal
   console.log("new style")
let message2 = `Hello ${student.name} from ${student.city}`;

console.log(message2);
