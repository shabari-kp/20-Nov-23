/*
in JS Functions are first class citizens which means you can

1)  assign a function to a variable
2) pass function as an argument
3)return a function from other functions

*/

function sayHello() {
    return "say hello";
    }

//assign a function to a variable

let fn=sayHello;

fn(); //this is same as a calling sayHello()

// pass function as an argument - callback

function greet(fn)
{
    console.log(fn);
}

greet(sayHello);

//return a function from other functions

function sayGoodBye()
 {
     return function()
     {
         return "Good Bye";
     }
 }


 let fun = sayGoodBye();
 let res = fun(); //returns Good Bye

 console.log(res);
