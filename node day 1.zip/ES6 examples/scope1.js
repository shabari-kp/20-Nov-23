
var name = 'Ted';
console.log(name);

function logName() {
    console.log("inside a function accessing global var  "+ name); // 'name' is accessible here and everywhere else
}

logName();