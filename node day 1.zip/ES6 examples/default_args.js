
/*
function add(num1=1,num2)
{
    return num1 + num2;
}

console.log(add(3,3)); 
console.log(add(3)); 
console.log(add(null,3));
console.log(add(undefined,3));

 //undefined has to be passed as a value 
 //for the default parameter to be considered.

*/

 function addition(num1=1,num2=2,num3=3)
{
    return num1 + num2+num3;
}

console.log(addition());
console.log(addition(10));

 