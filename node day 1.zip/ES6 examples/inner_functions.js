

function greet() {
    name = 'Shiva';
    return function () {
        console.log('Hi ' + name);
    }
}

greet(); //nothing happens

greetLetter = greet(); //greetLetter is function
greetLetter(); //calling the fnc

/*
The key thing to note here is that greetLetter function 
can access the name variable of the greet function 
even after it has been returned. 

One way to call the returned function from the greet function 
without variable assignment is by using 
parentheses () two times ()() like this:
*/

greet() ();