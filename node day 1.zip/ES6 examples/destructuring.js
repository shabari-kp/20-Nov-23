

var person = {name: "Sarah", country: "Nigeria", job: "Developer"};

console.log("old way");

var name = person.name;
    var country = person.country;
    var job = person.job;
        console.log(name); 
    console.log(country); 
    console.log(job); 
    console.log("====================");
    console.log("destructuring syn");

    var {name, country, job} = person;
    console.log(name); 
    console.log(country); 
    console.log(job); 

    console.log("====================");

    console.log("destructuring example 2 ");
    
    const array = [5, 7, 20];

let [a, b] = array;

console.log([a,b]);