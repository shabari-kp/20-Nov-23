
 
const name = 'Ted';

function logName() 
{
   var name="alex"; // a new variable
    console.log("inside a function ,value of name is   "+ name); // 'name' is accessible here and everywhere else
}

logName();

console.log(name);