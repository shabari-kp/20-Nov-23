/*When you return an inner function from a function, 
that returned function will not be called when you try to call the outer function. 
You must first save the invocation of the outer function in a separate variable and then 
call the variable as a function. 
Consider this example: */


function greet() {
    name = 'Shiva';
    return function () {
        console.log('Hi ' + name);
    }
}

 

greet(); // nothing happens, no errors
 

// the returned function from greet() gets saved in greetLetter
greetLetter = greet();

 // calling greetLetter calls the returned function from the greet() function
greetLetter(); // logs 'Hi Shiva'


/*
The key thing to note here is that greetLetter function 
can access the name variable of the greet function 
even after it has been returned. 
One way to call the returned function from the greet function 
without variable assignment is by using 
parentheses () two times ()() like this:
*/

greet()();