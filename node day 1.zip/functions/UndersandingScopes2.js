var foo = 1;

function bar () {
  var foo = 2;
  console.log('foo inside bar: ', foo);  
}

bar();

console.log('foo outside bar: ', foo)  