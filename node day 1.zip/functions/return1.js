function function1()
{
  return {
      myobject: "hello"
  };
}

function function2()
{
  return  
  {
    myobject: "hello"
  };
}

 
console.log("the output is :");
console.log(function2());