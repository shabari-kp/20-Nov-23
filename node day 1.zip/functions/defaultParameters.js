function add(num1=1,num2)
{
    return num1 + num2;
}

console.log(add(3,3)); // 6

console.log(add(3)); //gives NAN as the parameter specified is not known to be passed to which argument

//console.log(add(null,3));

console.log(add(undefined,3)); //undefined has to be passed as a value for the default parameter to be considered.