var name = 'Ted';

console.log(name); // logs 'Ted'

function logName() {
    console.log(name); // 'name' is accessible here and everywhere else
}

logName(); // logs 'Ted'