

let obj = {
    firstName: 'sarah',
    
    myFunc: function() { 
      console.log(this.firstName)  
    
      setTimeout(() => {
        console.log(this.firstName)
      }, 1000)
    }
  }
  obj.myFunc()
  
  
  /*
  
  There’s an even cleaner solution to this problem using arrow functions. Recall we said that arrow functions take their value of this from the lexical scope. That means it just uses the value of this in the surrounding code block. 
  
  It doesn’t care what calls it, it just cares where it was defined
  */