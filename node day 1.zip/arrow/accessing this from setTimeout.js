let obj = {
    firstName: 'sarah',
    
    myFunc: function() { 
      console.log(this.firstName)   ;
   
      setTimeout(function() {
  console.log("trying to access firstName in callback ie setTimeout");
        console.log(this.firstName); //scope of this is lost - hence prints undefined
      }, 1000)
    }
  }
  obj.myFunc() ;
  