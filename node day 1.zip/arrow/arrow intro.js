

function abc() {
    return 444;
  }

  let fc=abc();
  console.log(fc);

  () => 444;
 
  () => {555}
 
  let add = function(a,b) {
	return a + b;
};

let addWithArrow = (a,b) => a + b;