
let obj = {
    firstName: 'sarah',
    
    myFunc: function() {
        console.log("access firstname from myfunc");
      console.log(this.firstName); //because of closure
    }
  }
  
  obj.myFunc();