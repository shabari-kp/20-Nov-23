var myLogModule = require('./myLogcustomModule.js');

myLogModule.info('Node.js started');