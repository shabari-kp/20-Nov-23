module.exports = 'ROCK IT!';

 exports.name = function() {
    console.log('My name is Lemmy Kilmister');
};
 
