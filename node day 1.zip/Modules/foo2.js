module.exports.a = function () {
    console.log('a called');
};

module.exports.b = function () {
    console.log('b called');
};