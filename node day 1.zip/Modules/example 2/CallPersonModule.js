var person = require('./PersonModule.js');

var person = new person('a', 'bb');

console.log(person.fullName());