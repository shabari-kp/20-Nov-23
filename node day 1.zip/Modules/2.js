


var x=require("./1.js");
console.log(x.p1);
console.log(x.p2);
