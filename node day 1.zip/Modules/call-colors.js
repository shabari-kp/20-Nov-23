var x= require("./colors.js");

console.log(x);

var res=x.getRandomColor();

console.log( "random color is " + JSON.stringify(res));
 