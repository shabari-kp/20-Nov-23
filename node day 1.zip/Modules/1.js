

function add(){
    return 1+1;
}


function sub(){
    return 11-1;
}

exports.p1=add();
exports.p2=sub();
