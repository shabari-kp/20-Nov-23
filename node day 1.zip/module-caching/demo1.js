require("./mydata");
require("./MyData"); // this a new module as the filename is in different case
require("./Mydata"); // this a new module as the filename is in different case

 //if u have same filenames with same cas -> they will be cached by Node

 